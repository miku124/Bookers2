# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '089bb058668101d773da11aa808f5b83712057e8b27973e741fdf6c7ca1df88a7e9bb734677da839e39725599270d96f6e6d01d7b8737d1d795ee9c3e1956c2f'